let ball;

ball = {
  x: canvasWidth / 2,
  y: canvasHeight - 50,
  xVel: 0,
  yVel: -5,
}; 

let paddle = {
  x: canvasWidth / 2,
  width: paddleWidth,
};  


class Running{

runTheGame(){
    if (gameStarted) {
        drawPaddle(paddle.x, paddle.width);
        drawBall(ball.x, ball.y);
        drawLevel(level);
        timeStarted();
    
        ball.x = ball.x + ball.xVel;
        ball.y = ball.y + ball.yVel;
    
        handleBorders(ball);
        handleBallHitPaddle(ball, paddle);
        handleBallHitBlock(ball, level);
    
        if (keyIsDown(LEFT_ARROW)) {
          paddle.x = max(paddle.x - 8, 30);
        }
    
        if (keyIsDown(RIGHT_ARROW)) {
          paddle.x = min(paddle.x + 8, canvasWidth - paddle.width + 40);
        }
    
        if (paddle.x < 0) {
          paddle.x = canvasWidth;
        }
        if (paddle.x > canvasWidth) {
          paddle.x = 10;
        }
      } else {
        fill(0);
        textSize(32);
        text("Click to start", width / 2 - 100, height / 2 - 40);
        textSize(20);
        text("Press on arrows to move the paddle", width / 2 - 160, height / 2 + 5);
        textSize(20);
        text("Try to breack as much blocks", width / 2 - 145, height / 2 + 30);
      } 
}

}

function mouseClicked() {
  if (!gameStarted) {
    gameStarted = true;
  }
}
