function collideRectCircle(rx, ry, rw, rh, cx, cy, diameter) {
  let result = {
    intersect: false,
    side: null,
    x: cx,
    y: cy
  }

  if (cx < rx) {
    result.x = rx;
    result.side = "left";
  } else if (cx > rx + rw) {
    result.x = rx + rw;
    result.side = "right";
  }

  if (cy < ry) {
    result.y = ry;
    result.side = "top";
  } else if (cy > ry + rh) {
    result.y = ry + rh;
    result.side = "bottom";
  }

  var distance = this.dist(cx, cy, result.x, result.y)

  result.intersect = distance <= diameter / 2

  if(result.intersect) {
    score++;
    soundEffect.play();
  }
  if(score === 102){
    push();
    fill(0);
    textSize(30);
    text("You Won!", width / 2 - 75, height / 2);
    text("Click to play agian", width / 2 - 130, height / 2 + 40);
    pop();
    noLoop();
    restart = true;
  }
  return result;
}
function mousePressed() {
  if (restart) {
    location.reload();
  }
}

