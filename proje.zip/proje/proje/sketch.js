const canvasWidth = 400;
const canvasHeight = 500;
const ballSize = 12;
const blockWidth = 20;
const blockHeight = 10;
const paddleWidth = 80;
let gameStarted=false;
let restart=false;
let backgroundImage;
let soundEffect;
let gameOverSound;
let score = 0;
let run;


function preload() {
  backgroundImage = loadImage('photo/bc.jpg');
  soundEffect = loadSound('sound/ballSoundEffect.wav');
  gameOverSound = loadSound('sound/gameOver.mp3');
}

function setup() {
  createCanvas(canvasWidth, canvasHeight);
  run = new Running();
}

function draw() {
  background(backgroundImage);
  run.runTheGame();
  
}

function timeStarted(){
  if(gameStarted=true){
    let currrentTime=int(millis()/1000);
    textSize(20);
    fill(0);
    text("Time: "+ currrentTime, 30, 20);
    text("Score: "+ score, 270, 20);
  }
  else if(gameStarted=false) {
    noLoop();
  }
}

function drawBall(xpos, ypos) {
  fill(color("#582047"));
  ellipse(xpos, ypos, ballSize);
}

function drawPaddle(pos, width) {
  fill(color("#582047"));
  rect(pos - width / 2, canvasHeight - 20, width, 5);
}

function drawLevel(level) {
  for (i = 0; i < level.length; i++) {
    drawBlock(level[i]);
  }
}

function drawBlock(block) {
  let col;
  let hpCol = {
    1: "#E9C4DE",
    2: "#B27896",
    3: "#9C4773",
  };

  if (block.hp == 0) {
    return;
  }

  fill(hpCol[block.hp]);
  rect(block.x, block.y, blockWidth, blockHeight);
}

function handleBallHitPaddle(ball, paddle) {
  if (ball.y < canvasHeight - 25) {
    return;
  }

  if (ball.x < paddle.x - paddle.width / 2) {
    return;
  }

  if (ball.x > paddle.x + paddle.width / 2) {
    return;
  }

  ball.xVel = (ball.x - paddle.x) / 10;
  ball.yVel = -ball.yVel;
}

function handleBallHitBlock(ball, level) {
  let block;

  for (var i = 0; i < level.length; i++) {
    block = level[i];
    if (block.hp <= 0) {
      continue;
    }

    let collision = collideRectCircle(
      block.x,
      block.y,
      blockWidth,
      blockHeight,
      ball.x,
      ball.y,
      ballSize
    );

    if (collision.intersect == false) {
      continue;
    }

    let correction = ballSize / 2 + 1;

    switch (collision.side) {
      case "top":
        ball.y = collision.y - correction;
        ball.yVel = -ball.yVel;
        break;
      case "right":
        ball.x = collision.x + correction;
        ball.xVel = -ball.xVel;
        break;
      case "bottom":
        ball.y = collision.y + correction;
        ball.yVel = -ball.yVel;
        break;
      case "left":
        ball.x = collision.x - correction;
        ball.xVel = -ball.xVel;
        break;
    }

    block.hp = block.hp - 1;
  }
}

function handleBorders(ball) {
  if (ball.y < 0) {
    ball.yVel = -ball.yVel;
  }

  if (ball.x < 0) {
    ball.xVel = -ball.xVel;
  }

  if (ball.x > canvasWidth) {
    ball.xVel = -ball.xVel;
  }

  if (ball.y > canvasHeight) {
    push();
    fill(0);
    textSize(30);
    text("You lost", width / 2 - 65, height / 2 -40);
    text("Click to try again!", width / 2 - 120, height / 2 + 10);
    gameOverSound.play();
    pop();
    restart = true;
    text("Time: "+ currrentTime, 30, 380);
    text("Score: "+ score, 270, 20);
  }
}

function mousePressed() {
  if (restart) {
    location.reload();
  }
}
