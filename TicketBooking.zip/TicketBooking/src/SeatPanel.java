import javax.swing.*;

public class SeatPanel extends JFrame {

    public SeatPanel() {
        initComponents();
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jCheckBox8 = new javax.swing.JCheckBox();
        jCheckBox9 = new javax.swing.JCheckBox();
        jCheckBox18 = new javax.swing.JCheckBox();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        TotalPriceText = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jCheckBox1 = new javax.swing.JCheckBox();
        jCheckBox2 = new javax.swing.JCheckBox();
        jCheckBox3 = new javax.swing.JCheckBox();
        jCheckBox4 = new javax.swing.JCheckBox();
        jCheckBox5 = new javax.swing.JCheckBox();
        jCheckBox6 = new javax.swing.JCheckBox();
        jCheckBox7 = new javax.swing.JCheckBox();
        jCheckBox10 = new javax.swing.JCheckBox();
        jCheckBox11 = new javax.swing.JCheckBox();
        jCheckBox12 = new javax.swing.JCheckBox();
        jCheckBox13 = new javax.swing.JCheckBox();
        jCheckBox14 = new javax.swing.JCheckBox();
        jCheckBox15 = new javax.swing.JCheckBox();
        jCheckBox16 = new javax.swing.JCheckBox();
        jCheckBox17 = new javax.swing.JCheckBox();
        jCheckBox19 = new javax.swing.JCheckBox();
        jCheckBox20 = new javax.swing.JCheckBox();
        jCheckBox21 = new javax.swing.JCheckBox();
        jCheckBox22 = new javax.swing.JCheckBox();
        jCheckBox23 = new javax.swing.JCheckBox();
        jCheckBox24 = new javax.swing.JCheckBox();
        jCheckBox25 = new javax.swing.JCheckBox();
        jCheckBox26 = new javax.swing.JCheckBox();
        jCheckBox27 = new javax.swing.JCheckBox();
        jCheckBox28 = new javax.swing.JCheckBox();
        jCheckBox29 = new javax.swing.JCheckBox();
        jCheckBox30 = new javax.swing.JCheckBox();
        jCheckBox31 = new javax.swing.JCheckBox();
        jCheckBox32 = new javax.swing.JCheckBox();
        jCheckBox33 = new javax.swing.JCheckBox();
        jCheckBox34 = new javax.swing.JCheckBox();
        jCheckBox35 = new javax.swing.JCheckBox();
        jCheckBox36 = new javax.swing.JCheckBox();
        jCheckBox37 = new javax.swing.JCheckBox();
        jCheckBox38 = new javax.swing.JCheckBox();
        jCheckBox39 = new javax.swing.JCheckBox();
        jCheckBox40 = new javax.swing.JCheckBox();
        jCheckBox41 = new javax.swing.JCheckBox();
        jCheckBox42 = new javax.swing.JCheckBox();
        jCheckBox43 = new javax.swing.JCheckBox();
        jCheckBox44 = new javax.swing.JCheckBox();
        jCheckBox45 = new javax.swing.JCheckBox();
        jCheckBox46 = new javax.swing.JCheckBox();
        jCheckBox47 = new javax.swing.JCheckBox();
        jLabel1 = new javax.swing.JLabel();

        jCheckBox8.setText("jCheckBox8");

        jCheckBox9.setText("jCheckBox9");

        jCheckBox18.setText("jCheckBox18");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton1.setForeground(new java.awt.Color(0, 51, 102));
        jButton1.setText("Confirm");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, -1, -1));

        jButton2.setForeground(new java.awt.Color(0, 51, 102));
        jButton2.setText("Back to movie page");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, -1, -1));

        TotalPriceText.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        TotalPriceText.setForeground(new java.awt.Color(0, 51, 102));
        TotalPriceText.setEnabled(false);
        TotalPriceText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TotalPriceTextActionPerformed(evt);
            }
        });
        getContentPane().add(TotalPriceText, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, 140, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 51, 102));
        jLabel2.setText("Price");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, -1, -1));

        jCheckBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox1ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 30, 20, -1));

        jCheckBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox2ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox2, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 30, -1, -1));

        jCheckBox3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox3ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox3, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 30, -1, -1));

        jCheckBox4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox4ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox4, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 30, -1, -1));

        jCheckBox5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox5ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox5, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 30, -1, -1));

        jCheckBox6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox6ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox6, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 30, -1, -1));

        jCheckBox7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox7ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox7, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 30, -1, -1));

        jCheckBox10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox10ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox10, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 30, -1, -1));

        jCheckBox11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox11ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox11, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 100, -1, -1));

        jCheckBox12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox12ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox12, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 100, -1, -1));

        jCheckBox13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox13ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox13, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 100, -1, -1));

        jCheckBox14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox14ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox14, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 100, -1, -1));

        jCheckBox15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox15ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox15, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 100, -1, -1));

        jCheckBox16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox16ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox16, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 100, -1, -1));

        jCheckBox17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox17ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox17, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 100, -1, -1));

        jCheckBox19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox19ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox19, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 100, -1, -1));

        jCheckBox20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox20ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox20, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 170, -1, -1));

        jCheckBox21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox21ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox21, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 170, -1, -1));

        jCheckBox22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox22ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox22, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 170, -1, -1));

        jCheckBox23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox23ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox23, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 170, -1, -1));

        jCheckBox24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox24ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox24, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 170, -1, -1));

        jCheckBox25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox25ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox25, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 170, -1, -1));

        jCheckBox26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox26ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox26, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 170, -1, -1));

        jCheckBox27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox27ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox27, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 170, -1, -1));

        jCheckBox28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox28ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox28, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 240, -1, -1));

        jCheckBox29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox29ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox29, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 240, -1, -1));

        jCheckBox30.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox30ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox30, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 240, -1, -1));

        jCheckBox31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox31ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox31, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 240, -1, -1));

        jCheckBox32.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox32ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox32, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 240, -1, -1));

        jCheckBox33.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox33ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox33, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 300, -1, -1));

        jCheckBox34.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox34ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox34, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 300, -1, -1));

        jCheckBox35.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox35ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox35, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 300, -1, -1));

        jCheckBox36.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox36ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox36, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 300, -1, -1));

        jCheckBox37.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox37ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox37, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 300, -1, -1));

        jCheckBox38.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox38ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox38, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 300, -1, -1));

        jCheckBox39.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox39ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox39, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 370, -1, -1));

        jCheckBox40.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox40ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox40, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 370, -1, -1));

        jCheckBox41.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox41ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox41, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 370, -1, -1));

        jCheckBox42.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox42ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox42, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 370, -1, -1));

        jCheckBox43.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox43ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox43, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 370, -1, -1));

        jCheckBox44.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox44ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox44, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 370, -1, -1));

        jCheckBox45.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox45ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox45, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 300, -1, -1));

        jCheckBox46.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox46ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox46, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 300, -1, -1));

        jCheckBox47.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox47ActionPerformed(evt);
            }
        });
        getContentPane().add(jCheckBox47, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 370, -1, -1));

        jLabel1.setBackground(new java.awt.Color(51, 0, 0));
        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\farah\\Desktop\\seats.png")); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-40, -10, 580, 410));

        pack();
    }// </editor-fold>//GEN-END:initComponents
    int total=0;
    private void jCheckBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox1ActionPerformed
        if(jCheckBox1.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox1ActionPerformed

    private void TotalPriceTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TotalPriceTextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TotalPriceTextActionPerformed

    private void jCheckBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox2ActionPerformed
        if(jCheckBox2.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox2ActionPerformed

    private void jCheckBox3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox3ActionPerformed
        if(jCheckBox3.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox3ActionPerformed

    private void jCheckBox4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox4ActionPerformed
        if(jCheckBox4.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox4ActionPerformed

    private void jCheckBox5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox5ActionPerformed
        if(jCheckBox5.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox5ActionPerformed

    private void jCheckBox6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox6ActionPerformed
        if(jCheckBox6.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox6ActionPerformed

    private void jCheckBox7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox7ActionPerformed
        if(jCheckBox7.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox7ActionPerformed

    private void jCheckBox10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox10ActionPerformed
       if(jCheckBox10.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox10ActionPerformed

    private void jCheckBox11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox11ActionPerformed
        if(jCheckBox11.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox11ActionPerformed

    private void jCheckBox12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox12ActionPerformed
       if(jCheckBox12.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox12ActionPerformed

    private void jCheckBox13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox13ActionPerformed
        if(jCheckBox13.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox13ActionPerformed

    private void jCheckBox14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox14ActionPerformed
        if(jCheckBox14.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox14ActionPerformed

    private void jCheckBox15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox15ActionPerformed
        if(jCheckBox15.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox15ActionPerformed

    private void jCheckBox16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox16ActionPerformed
       if(jCheckBox16.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox16ActionPerformed

    private void jCheckBox17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox17ActionPerformed
        if(jCheckBox17.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox17ActionPerformed

    private void jCheckBox19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox19ActionPerformed
        if(jCheckBox19.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox19ActionPerformed

    private void jCheckBox20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox20ActionPerformed
        if(jCheckBox20.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox20ActionPerformed

    private void jCheckBox21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox21ActionPerformed
        if(jCheckBox21.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox21ActionPerformed

    private void jCheckBox22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox22ActionPerformed
        if(jCheckBox22.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox22ActionPerformed

    private void jCheckBox23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox23ActionPerformed
        if(jCheckBox23.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox23ActionPerformed

    private void jCheckBox24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox24ActionPerformed
        if(jCheckBox24.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox24ActionPerformed

    private void jCheckBox25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox25ActionPerformed
       if(jCheckBox25.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox25ActionPerformed

    private void jCheckBox26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox26ActionPerformed
        if(jCheckBox26.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox26ActionPerformed

    private void jCheckBox27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox27ActionPerformed
        if(jCheckBox27.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox27ActionPerformed

    private void jCheckBox28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox28ActionPerformed
        if(jCheckBox28.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox28ActionPerformed

    private void jCheckBox29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox29ActionPerformed
        if(jCheckBox29.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox29ActionPerformed

    private void jCheckBox30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox30ActionPerformed
       if(jCheckBox30.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox30ActionPerformed

    private void jCheckBox31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox31ActionPerformed
        if(jCheckBox31.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox31ActionPerformed

    private void jCheckBox32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox32ActionPerformed
        if(jCheckBox32.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox32ActionPerformed

    private void jCheckBox33ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox33ActionPerformed
        if(jCheckBox33.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox33ActionPerformed

    private void jCheckBox34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox34ActionPerformed
        if(jCheckBox34.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox34ActionPerformed

    private void jCheckBox35ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox35ActionPerformed
       if(jCheckBox35.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox35ActionPerformed

    private void jCheckBox36ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox36ActionPerformed
        if(jCheckBox36.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox36ActionPerformed

    private void jCheckBox37ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox37ActionPerformed
       if(jCheckBox37.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox37ActionPerformed

    private void jCheckBox38ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox38ActionPerformed
        if(jCheckBox38.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox38ActionPerformed

    private void jCheckBox39ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox39ActionPerformed
        if(jCheckBox39.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox39ActionPerformed

    private void jCheckBox40ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox40ActionPerformed
        if(jCheckBox40.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox40ActionPerformed

    private void jCheckBox41ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox41ActionPerformed
        if(jCheckBox41.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox41ActionPerformed

    private void jCheckBox42ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox42ActionPerformed
        if(jCheckBox42.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox42ActionPerformed

    private void jCheckBox43ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox43ActionPerformed
        if(jCheckBox43.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox43ActionPerformed

    private void jCheckBox44ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox44ActionPerformed
        if(jCheckBox44.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox44ActionPerformed

    private void jCheckBox45ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox45ActionPerformed
        if(jCheckBox45.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox45ActionPerformed

    private void jCheckBox46ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox46ActionPerformed
       if(jCheckBox46.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox46ActionPerformed

    private void jCheckBox47ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox47ActionPerformed
        if(jCheckBox47.isSelected()){
            total+=70;
        TotalPriceText.setText(String.valueOf(total)+" TL");
        }
        else{
            total=total-70;
            TotalPriceText.setText(String.valueOf(total) +" TL");
            
        }
    }//GEN-LAST:event_jCheckBox47ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if(TotalPriceText.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(rootPane, "Please choose a seat");
        }
        else{
            this.setVisible(false);
            dispose();
            new End().setVisible(true);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        this.setVisible(false);
        dispose();
        new All().setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SeatPanel().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField TotalPriceText;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JCheckBox jCheckBox10;
    private javax.swing.JCheckBox jCheckBox11;
    private javax.swing.JCheckBox jCheckBox12;
    private javax.swing.JCheckBox jCheckBox13;
    private javax.swing.JCheckBox jCheckBox14;
    private javax.swing.JCheckBox jCheckBox15;
    private javax.swing.JCheckBox jCheckBox16;
    private javax.swing.JCheckBox jCheckBox17;
    private javax.swing.JCheckBox jCheckBox18;
    private javax.swing.JCheckBox jCheckBox19;
    private javax.swing.JCheckBox jCheckBox2;
    private javax.swing.JCheckBox jCheckBox20;
    private javax.swing.JCheckBox jCheckBox21;
    private javax.swing.JCheckBox jCheckBox22;
    private javax.swing.JCheckBox jCheckBox23;
    private javax.swing.JCheckBox jCheckBox24;
    private javax.swing.JCheckBox jCheckBox25;
    private javax.swing.JCheckBox jCheckBox26;
    private javax.swing.JCheckBox jCheckBox27;
    private javax.swing.JCheckBox jCheckBox28;
    private javax.swing.JCheckBox jCheckBox29;
    private javax.swing.JCheckBox jCheckBox3;
    private javax.swing.JCheckBox jCheckBox30;
    private javax.swing.JCheckBox jCheckBox31;
    private javax.swing.JCheckBox jCheckBox32;
    private javax.swing.JCheckBox jCheckBox33;
    private javax.swing.JCheckBox jCheckBox34;
    private javax.swing.JCheckBox jCheckBox35;
    private javax.swing.JCheckBox jCheckBox36;
    private javax.swing.JCheckBox jCheckBox37;
    private javax.swing.JCheckBox jCheckBox38;
    private javax.swing.JCheckBox jCheckBox39;
    private javax.swing.JCheckBox jCheckBox4;
    private javax.swing.JCheckBox jCheckBox40;
    private javax.swing.JCheckBox jCheckBox41;
    private javax.swing.JCheckBox jCheckBox42;
    private javax.swing.JCheckBox jCheckBox43;
    private javax.swing.JCheckBox jCheckBox44;
    private javax.swing.JCheckBox jCheckBox45;
    private javax.swing.JCheckBox jCheckBox46;
    private javax.swing.JCheckBox jCheckBox47;
    private javax.swing.JCheckBox jCheckBox5;
    private javax.swing.JCheckBox jCheckBox6;
    private javax.swing.JCheckBox jCheckBox7;
    private javax.swing.JCheckBox jCheckBox8;
    private javax.swing.JCheckBox jCheckBox9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    // End of variables declaration//GEN-END:variables
}
